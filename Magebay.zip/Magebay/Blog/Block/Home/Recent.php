<?php
/**
 * Copyright � 2015  (magebay99@gmail.com). All rights reserved.
 * See LICENSE.txt for license details (http://opensource.org/licenses/osl-3.0.php).
 *
 * 
 */

namespace Magebay\Blog\Block\Home;

class Recent extends \Magebay\Blog\Block\Post\PostList\AbstractList
{
    /**
     * @return $this
     */
    public function _construct()
    {
        if($this->_scopeConfig->getValue('themes/blog/slide',\Magento\Store\Model\ScopeInterface::SCOPE_STORE)){
			if($this->_scopeConfig->getValue('themes/blog/amount',\Magento\Store\Model\ScopeInterface::SCOPE_STORE)){
				$amount = (int) $this->_scopeConfig->getValue('themes/blog/amount',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
			}else{ $amount= 5; }
        }else{ $amount= 5; }
		$this->setPageSize($amount);
        return parent::_construct();
    }
	protected function _preparePostCollection()
    {
        $this->_postCollection = $this->_postCollectionFactory->create()
            ->addActiveFilter()
            ->addStoreFilter($this->_storeManager->getStore()->getId())->addFieldToFilter('featured_img', array("notnull" => true))
            ->setOrder('publish_time', 'DESC');

        if ($this->getPageSize()) {
            $this->_postCollection->setPageSize($this->getPageSize());
        }
    }
	
}
