<?php
/**
 * Copyright © 2015  (magebay99@gmail.com). All rights reserved.
 * See LICENSE.txt for license details (http://opensource.org/licenses/osl-3.0.php).
 *
 * 
 */

namespace Magebay\Blog\Controller\Adminhtml\Post;

/**
 * Blog post grid controller
 */
class Grid extends \Magebay\Blog\Controller\Adminhtml\Post
{

}
