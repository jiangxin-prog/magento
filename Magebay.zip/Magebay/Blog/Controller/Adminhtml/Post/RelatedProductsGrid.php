<?php
/**
 * Copyright © 2015  (magebay99@gmail.com). All rights reserved.
 * See LICENSE.txt for license details (http://opensource.org/licenses/osl-3.0.php).
 *
 * 
 */

namespace Magebay\Blog\Controller\Adminhtml\Post;

/**
 * Blog post related products grid controller
 */
class RelatedProductsGrid extends RelatedProducts
{

}
