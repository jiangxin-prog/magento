<?php
 
namespace Magebay\Bookingsystem\Block\Adminhtml\Facilities;
 
use Magento\Backend\Block\Widget\Grid as WidgetGrid;
 
class Grid extends WidgetGrid
{
	
}