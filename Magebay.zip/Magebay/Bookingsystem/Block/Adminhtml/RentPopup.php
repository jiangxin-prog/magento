<?php

namespace Magebay\Bookingsystem\Block\Adminhtml;

use Magento\Backend\Block\Template;
use Magento\Framework\View\Element\FormKey;
use Magebay\Bookingsystem\Helper\Data as BkHelper;

class RentPopup extends Template
{
	/**
     * @param \Magebay\Bookingsystem\Helper\Data
     *
     */
	protected $_bkHelper;
	protected $_fromKey;
	function __construct(
		\Magento\Backend\Block\Widget\Context $context,
		BkHelper $bkHelper,
        FormKey $formKey,
		array $data = []
	)
	{
		$this->_bkHelper = $bkHelper;
		$this->_fromKey = $formKey;
		parent::__construct($context, $data);
	}
	function getBkRequestData()
	{
		$bookingId = $this->getBookingId();
		$bookingType = $this->getBookingType();
		$bookingTime = $this->getBookingTime();
		return array(
			'booking_id'=>$bookingId,
			'booking_type'=>$bookingType,
			'booking_time'=>$bookingTime
		);
	}
	function getBkFormKey() {
	    return $this->_fromKey->getFormKey();
    }
	function getBkAjaxUrl() {
	    $uploadUrl = $this->_bkHelper->getBkAdminAjaxUrl('bookingsystem/booking/UploadCsvFile');
	    return array(
            'upload_csv'=>$uploadUrl
        );
    }
    function getMediaUrl() {
	    return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }
}
