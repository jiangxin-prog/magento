<?php

namespace Magebay\Bookingsystem\Block\Marketplace;
 
use Magento\Framework\View\Element\Template;
use Magebay\Bookingsystem\Helper\Data as BkHelper;

/**
 * Class RentPopup
 * @package Magebay\Bookingsystem\Block\Marketplace
 */
class RentPopup extends Template
{
	/**
     * @param \Magebay\Bookingsystem\Helper\Data
     * 
     */
	protected $_bkHelper;
    /**
     * @var \Magento\Framework\View\Element\FormKey
     */
    protected $_fromKey;

    /**
     * RentPopup constructor.
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\View\Element\FormKey $formKey
     * @param BkHelper $bkHelper
     * @param array $data
     */
    function __construct(
		\Magento\Backend\Block\Widget\Context $context,
		\Magento\Framework\View\Element\FormKey $formKey,
		BkHelper $bkHelper,
		array $data = []
	)
	{
		$this->_bkHelper = $bkHelper;
		$this->_fromKey = $formKey;
		parent::__construct($context, $data);
	}

    /**
     * @return array
     */
    function getBkRequestData()
	{
		$bookingId = $this->getBookingId();
		$bookingType = $this->getBookingType();
		$bookingTime = $this->getBookingTime();
		return array(
			'booking_id'=>$bookingId,
			'booking_type'=>$bookingType,
			'booking_time'=>$bookingTime
		);
	}

    /**
     * @return string
     */
    function getBkFormKey() {
        return $this->_fromKey->getFormKey();
    }

    /**
     * @return array
     */
    function getBkAjaxUrl() {
        $uploadUrl = $this->_bkHelper->getBkFrontendAjaxUrl($this->getUrl('bookingsystem/marketplace/UploadCsvFile'));
        return array(
            'upload_csv'=>$uploadUrl
        );
    }

    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    function getMediaUrl() {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }
}