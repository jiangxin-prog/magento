<?php

namespace Magebay\Bookingsystem\Controller\Adminhtml\Booking;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Magebay\Bookingsystem\Model\BookingimagesFactory;
use Magebay\Bookingsystem\Model\Image as ImageModel;
use Magebay\Bookingsystem\Model\Upload as UploadImages;
use Magento\Framework\App\ResourceConnection;

class UploadCsvFile extends Action
{
	 /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
    /**
     * Result page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */

    protected $_resultPageFactory;
	 /**
     * Result page factory
     *
     * @var \Magento\Framework\Controller\Result\JsonFactory;
     */
	protected $_resultJsonFactory;
	/**
     * Image model
     *
     * @var  \Magebay\Bookingsystem\Model\Image;
     */
	protected $_imageModel;
	/**
     * Image images
     *
     * @var  \Magebay\Bookingsystem\Model\Upload;
     */
	protected $_uploadImages;
	/**
     * Image images
     *
     * @var  \Magebay\Bookingsystem\Model\Bookingimages;
     */
	protected $_bookingimages;
	protected $_resourceConnection;
	protected $_calendarModel;
	protected $_authSession;
	function __construct
	(
		Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
		JsonFactory $resultJsonFactory,
        ResourceConnection $resourceConnection,
        \Magento\Backend\Model\Auth\Session $authSession,
		ImageModel $ImageModel,
		UploadImages $uploadImages,
		\Magebay\Bookingsystem\Model\Calendars $calendars,
		BookingimagesFactory $bookingimages
	)
	{
		parent::__construct($context);
		$this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
		$this->_resultJsonFactory = $resultJsonFactory;
		$this->_resourceConnection = $resourceConnection;
		$this->_authSession = $authSession;
		$this->_calendarModel = $calendars;
		$this->_imageModel = $ImageModel;
		$this->_uploadImages = $uploadImages;
		$this->_bookingimages = $bookingimages;
	}
	public function execute()
	{
		$resultJson = $this->_resultJsonFactory->create();
		//upload image
		$formData = $this->getRequest()->getParams();
        $response = array('status'=>'status','message'=>__('error, Please check again'),'filename'=>'','html'=>'');
        $cvsFile = 'booking-price'.date('Y-m-d_h-i-s').'.csv';
        $csvDir = str_replace('image','csv',$this->_imageModel->getBaseDir());
        $resource = $this->_resourceConnection;
        $tableName = $resource->getTableName('booking_calendars');
        $connection = $resource->getConnection();
        $params = $this->getRequest()->getParams();
		try{
            $action = isset($params['action']) ? $params['action'] : 'check';
            if($action == 'import')
            {
                $inputFileName = isset($params['bk_csv_file']) ? $params['bk_csv_file'] : '';
                $sessionImport = $this->_authSession->getData('booking_price');
                $fileName = isset($sessionImport['file_name']) ? $sessionImport['file_name'] : '';
                $sqlInsert = isset($sessionImport['sql_query']) ? $sessionImport['sql_query'] : '';
                $bookingId = isset($sessionImport['booking_id']) ? $sessionImport['booking_id'] : '';
                $bookingType = isset($sessionImport['booking_type']) ? $sessionImport['booking_type'] : '';
                if($fileName != $inputFileName && $sqlInsert != '')
                {
                    if($connection->query($sqlInsert))
                    {
                        $response['status'] = 'success';
                        $response['message'] = __('You have imported successfully!');
                        $dataSend = array('booking_id'=>$bookingId,'booking_type'=>$bookingType);
                        $response['html'] = $this->_view->getLayout()->createBlock('Magebay\Bookingsystem\Block\Adminhtml\Calendars')->setData($dataSend)->setTemplate('Magebay_Bookingsystem::catalog/product/calendars/items.phtml')->toHtml();
                    }
                }
                $this->_authSession->setBookingPrice(array());
            }
            else
            {
                $fileName = $this->_uploadImages->uploadFileAndGetName('bk_csv_file', $csvDir, $formData,$cvsFile);
                $okCheck = true;
                if($fileName == -1)
                {
                    $okCheck = false;
                }
                $fullFileName = $csvDir.'/'.$fileName;
                $numberExit = 0;
                $fixedBookingId = $this->getRequest()->getParam('csv_booking_id',0);
                $fixedBookingId = (int)$fixedBookingId;
                $fixedBookingType = $this->getRequest()->getParam('csv_booking_type','per_day');
                if ($okCheck == true && $fixedBookingId > 0 && ($handle = fopen($fullFileName, "r")) !== FALSE) {
                    $row = 0;
                    $okCheck = false;
                    // $query = "(`calendar_id`, `calendar_startdate`, `calendar_enddate`, `calendar_qty`, `calendar_status`, `calendar_price`, `calendar_promo`, `calendar_booking_id`, `calendar_default_value`, `calendar_booking_type`, `extract_persons`) VALUES (NULL, '2018-12-04', '2018-12-06', '0', 'available', '10', '20', '1', '2', 'per_day', NULL);";
                    $sql = "INSERT INTO " .$tableName . " (calendar_id,calendar_startdate,calendar_enddate,calendar_qty,calendar_status,calendar_price,calendar_promo,calendar_booking_id,calendar_default_value,calendar_booking_type,extract_persons) VALUES ";
                    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                        $checkIn = $data[1];
                        $checkOut = $data[2];
                        $qty = $data[3];
                        $status = $data[4];
                        $price = $data[5];
                        $promo = $data[6];
                        $bookingId = $fixedBookingId;
                        $defaultValue = $data[7];
                        $bookingType = $data[8];
                        $person = $data[9];
                        if(trim($status) === '')
                        {
                            continue;
                        }
                        if($fixedBookingType != $bookingType)
                        {
                            continue;
                        }
                        $checkExit = $this->_calendarModel->getCalendarSpecialDays($bookingId,$checkIn,$bookingType);
                        if($checkExit && $checkExit->getId()){
                            $numberExit++;
                            continue;
                        }
                        $okCheck = true;
                        if($row == 0)
                        {
                            $sql .= "(NULL, '{$checkIn }','{$checkOut}','{$qty}','{$status}','{$price}','{$promo}','{$bookingId}','{$defaultValue}','{$bookingType}',{$person})";
                        }
                        else {
                            $sql .= ", (NULL,'{$checkIn }','{$checkOut}','{$qty}','{$status}','{$price}','{$promo}','{$bookingId}','{$defaultValue}','{$bookingType}',{$person})";
                        }
                        $row++;
                    }
                    fclose($handle);
                    $dataImport = array(
                        'file_name'=>$fileName,
                        'sql_query'=>$sql,
                        'booking_id'=>$fixedBookingId,
                        'booking_type'=>$fixedBookingType
                    );
                    $this->_authSession->setBookingPrice($dataImport);
                    $response['status'] = 'success';
                    $response['file_name'] = $fileName;
                    if(!$okCheck)
                    {
                        $response['file_name'] = '';
                        $response['status'] = 'error';
                        $response['message'] = __('Nothing to import, You data is incorrect!');
                    }
                    elseif($numberExit > 0)
                    {
                        $response['message'] = __('Some data is already, We will ignore them, Click to Import if you want to continue!');
                    }
                    else {
                        $response['message'] = __('Check Data success, Click to import to import Booking Price');
                    }

                }
            }

        } catch (\Exception $e) {
            $response['message'] = $e->getMessage();
		}

		return $resultJson->setData($response);
	}
	protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Magebay_Bookingsystem::update_booking');
    }
}
