<?php
/**
 * Created by PhpStorm.
 * User: maiuoc
 * Date: 2019-01-04
 * Time: 10:57 AM
 */

namespace Magebay\Bookingsystem\Controller\Index;

use Magento\Checkout\Model\Cart;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\Action;
class ClearCart extends Action
{
    protected  $_modelCart;
    protected $checkoutSession;
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CheckoutSession $checkoutSession,
        Cart $modelCart)
    {
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
        $this->_modelCart = $modelCart;
    }
    public function execute()
    {
        echo '121222';
        $cart = $this->_modelCart;
        $quoteItems = $this->checkoutSession->getQuote()->getItemsCollection();
        foreach($quoteItems as $item)
        {
            $cart->removeItem($item->getId())->save();
        }
    }
}