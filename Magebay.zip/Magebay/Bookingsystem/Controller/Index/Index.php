<?php
/**
 *
 * 888b     d888          d8b      888     888
 * 8888b   d8888          Y8P      888     888
 * 88888b.d88888                   888     888
 * 888Y88888P888  8888b.  888      888     888  .d88b.   .d8888b
 * 888 Y888P 888     "88b 888      888     888 d88""88b d88P"
 * 888  Y8P  888 .d888888 888      888     888 888  888 888
 * 888   "   888 888  888 888      Y88b. .d88P Y88..88P Y88b.
 * 888       888 "Y888888 888       "Y88888P"   "Y88P"   "Y8888P
 * /
 * *
 *  * --*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*-- *
 *  * @PROJECT    : Booking Extension Pro [Magebay.com]
 *  * @AUTHOR     : Maiuoc - Magebay Developer
 *  * @COPYRIGHT  : © 2016 Magebay - Magento Ext Provider
 *  * @LINK       : https://www.magebay.com/
 *  * @FILE       : Config.php
 *  * @CREATED    : 2:50 PM , 05/Jul/2016
 *  * @DETAIL     :
 *  * --*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*-- *
 *  *
 *
 */

namespace Magebay\Bookingsystem\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magebay\Bookingsystem\Helper\Data as BkHelper;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_bkHelper;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
    */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
		BkHelper $bkHelper
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->_bkHelper = $bkHelper;
    }
    public function execute()
    {
		$enableSearch = $this->_bkHelper->getFieldSetting('bookingsystem/search_setting/enable_search');
		$enable = $this->_bkHelper->getFieldSetting('bookingsystem/setting/enable');
		if($enable == 1 && $enableSearch == 1)
		{
			 $resultPageFactory = $this->resultPageFactory->create();
 
			// Add page title
			$resultPageFactory->getConfig()->getTitle()->set(__('Find Your Booking'));
	 
			// Add breadcrumb
		   /** @var \Magento\Theme\Block\Html\Breadcrumbs */
		   if($resultPageFactory->getLayout()->getBlock('breadcrumbs'))
		   {
			    $breadcrumbs = $resultPageFactory->getLayout()->getBlock('breadcrumbs');
				$breadcrumbs->addCrumb('home',
					[
						'label' => __('Home'),
						'title' => __('Home'),
						'link' => $this->_url->getUrl('')
					]
				);
				$breadcrumbs->addCrumb('booking_search',
					[
						'label' => __('Booking Search'),
						'title' => __('Booking Search')
					]
				);
		   }
			return $resultPageFactory;
		}
    }
}
 