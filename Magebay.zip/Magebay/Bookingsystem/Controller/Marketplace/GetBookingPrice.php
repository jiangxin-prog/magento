<?php
/**
 * Created by PhpStorm.
 * User: maiuoc
 * Date: 12/20/2018
 * Time: 9:10 AM
 */

namespace Magebay\Bookingsystem\Controller\Marketplace;

use \Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;

class GetBookingPrice extends Action
{
    protected $_jsonFactory;
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        JsonFactory $jsonFactory
    )
    {
        parent::__construct($context);
        $this->_jsonFactory = $jsonFactory;
    }
    function execute()
    {
        // TODO: Implement execute() method.
        $response = array(
          'html'=>'',
          'status'=>'error',
          'message'=>__('System can not load data, Please check again!')
        );
        $bookingId = $this->getRequest()->getParam('booking_id',0);
        $bookingType = $this->getRequest()->getParam('booking_type','per_day');
        $dataSend = array(
            'booking_id'=>$bookingId,
            'booking_type'=>$bookingType
        );
        try {
            $response['status'] = 'success';
            $response['html'] = $this->_view->getLayout()->createBlock('Magebay\Bookingsystem\Block\Marketplace\Calendars')->setData($dataSend)->setTemplate('Magebay_Bookingsystem::marketplace/calendars/items.phtml')->toHtml();
        }
        Catch(\Exception $exception)
        {
            $response['message'] = $exception->getMessage();
        }
        return $this->_jsonFactory->create()->setData($response);
    }
}