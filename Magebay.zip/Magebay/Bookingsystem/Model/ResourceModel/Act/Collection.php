<?php
/**
* @package    Magebay_Bookingsystem
* @version    2.0
* @author     Magebay Developer Team <magebay99@gmail.com>
* @website    http://www.productsdesignercanvas.com
* @copyright  Copyright (c) 2009-2016 MAGEBAY.COM. (http://www.magebay.com)
*/
namespace Magebay\Bookingsystem\Model\ResourceModel\Act;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Constructor
     * Configures collection
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Magebay\Bookingsystem\Model\Act', 'Magebay\Bookingsystem\Model\ResourceModel\Act');
    }
}