<?php 

namespace Magebay\Bookingsystem\Model\System\Config\Product;


class Attributes implements \Magento\Framework\Option\ArrayInterface
{

	protected $_attributeFactory;
	
	public function __construct(
		\Magento\Catalog\Model\ResourceModel\Eav\Attribute $attributeFactory
	) {
		$this->_attributeFactory = $attributeFactory;
	}

	 /**
	 * Options getter
	 *
	 * @return array
	 */
	public function toOptionArray( $isMultiselect = false)
	{
		$attributes = $this->_attributeFactory->getCollection();
		$options = array();
		$arAttrs = array();
		$i = 0;
		foreach($attributes as $attribute)
		{
			$mAttribute = $this->_attributeFactory->loadByCode(\Magento\Catalog\Model\Product::ENTITY, $attribute->getAttributecode());
			$arAttrs[$i] = $attribute->getData();
			$arAttrs[$i]['position'] = (int)$mAttribute->getPosition();
			$i++;
		}
		if(count($arAttrs))
		{
			for($j = 0; $j < count($arAttrs) - 1; $j++)
			{
				for($l = 0; $l < (count($arAttrs) - 1 - $j); $l++)
				{
					if($arAttrs[$l + 1]['position'] < $arAttrs[$l]['position'])
					{
						$temp = $arAttrs[$l];
						$arAttrs[$l] = $arAttrs[$l + 1];
						$arAttrs[$l + 1] = $temp;
					}
					
				}
			}
			foreach ($arAttrs as $arAttr){
				if($arAttr['attribute_code'] != '' && $arAttr['frontend_label'] != '' && ($arAttr['frontend_input'] == 'select' || $arAttr['frontend_input'] == 'multiselect'))
				{
					$options[] = array('label'=>$arAttr['frontend_label'],'value'=>$arAttr['attribute_code']);
				}
			} 
		}
		
       return $options;
	}
} 
