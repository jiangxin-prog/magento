<?php
/******************************************************************************
 * 888b     d888          d8b      888     888                                *
 * 8888b   d8888          Y8P      888     888                                *
 * 88888b.d88888                   888     888                                *
 * 888Y88888P888  8888b.  888      888     888  .d88b.   .d8888b              *
 * 888 Y888P 888     "88b 888      888     888 d88""88b d88P"                 *
 * 888  Y8P  888 .d888888 888      888     888 888  888 888                   *
 * 888   "   888 888  888 888      Y88b. .d88P Y88..88P Y88b.                 *
 * 888       888 "Y888888 888       "Y88888P"   "Y88P"   "Y8888P              *
 *  * --*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*-- *                    *
 *  * @PROJECT    : Booking Extension Pro [Magebay.com]                       *
 *  * @AUTHOR     : Maiuoc - Magebay Developer                                *
 *  * @COPYRIGHT  : © 2016 Magebay - Magento Ext Provider                     *
 *  * @LINK       : https://www.magebay.com/                                  *
 *  * @FILE       : Config.php                                                *
 *  * @CREATED    : 2:50 PM , 05/Jul/2016                                     *
 *  * @DETAIL     :                                                           *
 *  * --*--*--*--*--*--*--*--*--*--*--*--*--*--*--*--*-- *                    *
 *                                                                            *
 *                                                                            *
 ******************************************************************************/
namespace Magebay\Bookingsystem\Observer\Frontend;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magebay\Bookingsystem\Helper\BkCustomOptions;
use Magento\Checkout\Model\Cart as CustomerCart;
class Extraoption implements ObserverInterface {
    protected $http;
	/**
	* var Magebay\Bookingsystem\Helper\BkCustomOptions
	**/
    protected $_bkCustomOptions;
	protected $_cart;
	protected $_productMetadata;
	protected $_json;
    public function __construct(
        \Magento\Framework\App\Request\Http $http,
		\Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
		\Magento\Framework\Serialize\Serializer\Json $json,
		BkCustomOptions $bkCustomOptions
    ) {
        $this->http = $http;
		$this->_cart = $cart;
		$this->_bkCustomOptions = $bkCustomOptions;
		$this->_productMetadata = $productMetadata;
		$this->_json = $json;
    }
    public function execute(\Magento\Framework\Event\Observer $observer) {
        // set the additional options on the product
		$actionName = "";
		try {
            $action = $this->http;
            if($action) {
                $actionName = $this->http->getFullActionName();    
            }
		} catch(\Exception $e) {
			$actionName = "";
		}
        if ($actionName == 'checkout_cart_add')
        {
            // assuming you are posting your custom form values in an array called extra_options...
            $params = $this->http->getParams();
            if (count($params))
            {
				if(isset($params['bk_item_id']) && (int)$params['bk_item_id'] > 0)
				{
					$bkItemId = (int)$params['bk_item_id'];
					$this->_cart->removeItem($bkItemId);
				}
                $product = $observer->getProduct();
				$bookingOPtions = $this->_bkCustomOptions->createExtractOptions($product,$params);
				if($bookingOPtions['status'] == false)
				{
					throw new \Exception(__('Dates are not available. Please check again!'));
				}
				else
				{
                   /* $version = $this->_productMetadata->getVersion();
                    if(version_compare($version, '2.2.0') >= 0)
                    {
                        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                        $json = $objectManager->get('Magento\Framework\Serialize\Serializer\Json');
                        $additionalOptions = $bookingOPtions['bk_options'];
                        $jsonOptions = $json->serialize($additionalOptions);
                        $observer->getProduct()
                            ->addCustomOption('additional_options', $jsonOptions);
                    }
                    else{
                        $additionalOptions = $bookingOPtions['bk_options'];
                        $observer->getProduct()
                            ->addCustomOption('additional_options', serialize($additionalOptions));
                    }*/
                    $additionalOptions = $bookingOPtions['bk_options'];
                    $jsonOptions = $this->_json->serialize($additionalOptions);
                    $observer->getProduct()
                        ->addCustomOption('additional_options', $jsonOptions);
				}               
            }
        }
    }
}