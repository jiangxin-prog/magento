<?php

namespace Magebay\Bookingsystem\Observer\Frontend;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class Getquote implements ObserverInterface
{
    protected $_checkoutSession;
    protected $_bkHelperDate;
    protected $_bookingOrderFactory;
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magebay\Bookingsystem\Helper\BkHelperDate $bkHelperDate,
        \Magebay\Bookingsystem\Model\BookingordersFactory $bookingordersFactory
    )
    {
        $this->_checkoutSession = $checkoutSession;
        $this->_bkHelperDate = $bkHelperDate;
        $this->_bookingOrderFactory = $bookingordersFactory;
    }

    public function execute(Observer $observer)
    {
        $product = $observer->getEvent()->getDataByKey('product');

        /** @var \Magento\Quote\Model\Quote\Item $item */
        $item = $this->_checkoutSession->getQuote()->getItemByProduct($product);
        $_customOptions = $item->getProduct()->getTypeInstance(true)->getOrderOptions($item->getProduct());
        $itemId = $item->getId();
        $params = isset($_customOptions['info_buyRequest']) ? $_customOptions['info_buyRequest'] : array();
        if(count($params))
        {
            $this->updateBkQuoteItem($itemId,$params);
        }
    }
    private function updateBkQuoteItem($itemId = 0, $params = array())
    {
        //\Zend_Debug::dump($params);
        $checkIn = isset($params['check_in']) ? $params['check_in'] : '';
        $formatDate = $this->_bkHelperDate->getFieldSetting('bookingsystem/setting/format_date');
        $checkOut = isset($params['check_out']) ? $params['check_out'] : '';
        $roomId = 0;
        if(isset($params['room_id']) && $params['room_id'] > 0)
        {
            $roomId = $params['room_id'];
            $checkIn = isset($params['room_check_in']) ? $params['room_check_in'] : '';
            $checkOut = isset($params['room_check_out']) ? $params['room_check_out'] : '';
        }
        if($this->_bkHelperDate->validateBkDate($checkIn,$formatDate))
        {
            $checkIn = $this->_bkHelperDate->convertFormatDate($checkIn);
        }
        else
        {
            $checkIn = '';
        }
        if($this->_bkHelperDate->validateBkDate($checkOut,$formatDate))
        {
            $checkOut = $this->_bkHelperDate->convertFormatDate($checkOut);
        }
        else
        {
            $checkOut = '';
        }
        $qty = isset($params['qty']) ? $params['qty'] : 1;
        $bookingId = isset($params['product']) ? $params['product'] : 0;
        $timeSlots = '';
        if(isset($params['intervals_hours']) && count($params['intervals_hours']))
        {
            $timeSlots = implode(',',$params['intervals_hours']);
            $checkOut = $checkIn;
        }
        $serviceStart = isset($params['service_start']) ? $params['service_start'] : '';
        $serviceEnd = isset($params['service_end']) ? $params['service_end'] : '';
        if($checkIn != '' && $checkOut != '')
        {
            $dataSave = array(
                'bkorder_check_in'=>$checkIn,
                'bkorder_check_out'=>$checkOut,
                'bkorder_customer'=>'',
                'bkorder_qty'=>$qty,
                'bkorder_booking_id'=>$bookingId,
                'bkorder_room_id'=>$roomId,
                'bkorder_order_id'=>0,
                'bkorder_service_start'=>$serviceStart,
                'bkorder_service_end'=>$serviceEnd,
                'bkorder_total_days'=>'',
                'bkorder_qt_item_id'=>$itemId,
                'bkorder_quantity_interval'=>'',
                'bkorder_interval_time'=>$timeSlots
            );
            $bookingOrder = $this->_bookingOrderFactory->create();
            try{
                $bookingOrder->setData($dataSave)->save();
            }
            catch (\Exception $e)
            {
                 //echo $e->getMessage();
            }
        }

      // die();
    }
}