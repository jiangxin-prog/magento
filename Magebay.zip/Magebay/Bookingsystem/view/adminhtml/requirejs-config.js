var config = {
		map: {
		'*': {
			bk_calendar : 'Magebay_Bookingsystem/js/calendar',
			bk_map_js : 'Magebay_Bookingsystem/js/bk_maps',
			bk_moment_min : 'Magebay_Bookingsystem/js/moment.min',
			bk_fullcalendar_min : 'Magebay_Bookingsystem/js/fullcalendar.min',
			bk_calendar_simple_order : 'Magebay_Bookingsystem/js/order/calendar_simple',
			bk_calendar_intervals_order : 'Magebay_Bookingsystem/js/order/calendar_intervals',
			bk_calendar_rooms_order : 'Magebay_Bookingsystem/js/order/calendar_rooms',
            bk_google_map : 'Magebay_Bookingsystem/js/bk_google_map',
			}
		}
};