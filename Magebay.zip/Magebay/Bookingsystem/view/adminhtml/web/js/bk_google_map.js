define([],function () {
    console.log('Website do not use google map');
})