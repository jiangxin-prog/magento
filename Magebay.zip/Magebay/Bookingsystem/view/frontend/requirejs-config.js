var config = {
		map: {
		'*': {
			bk_bootstrap_min : 'Magebay_Bookingsystem/js/bootstrap.min',
			bk_owl_carousel : 'Magebay_Bookingsystem/js/owl.carousel',
			bk_calendar_simple : 'Magebay_Bookingsystem/js/calendar',
			bk_calendar_market : 'Magebay_Bookingsystem/js/marketplace/calendar_market',
			bk_calendar_intervals : 'Magebay_Bookingsystem/js/calendar_intervals',
			bk_calendar_room : 'Magebay_Bookingsystem/js/room_calendar',
			bk_map_point : 'Magebay_Bookingsystem/js/map_point',
			bk_map_js : 'Magebay_Bookingsystem/js/marketplace/bk_maps',
			bk_calendar_rage : 'Magebay_Bookingsystem/js/daterangepicker',
            bk_google_map : 'Magebay_Bookingsystem/js/bk_google_map'
			}
		}
};